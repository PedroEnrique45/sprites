﻿// -----------------------------------------------------------------------
// <copyright file="IMeshRenderer.cs" company="">
// TODO: Update copyright text.
// </copyright>
// -----------------------------------------------------------------------

namespace TMeshRenderer.Core
{
    using System;

    /// <summary>
    /// TODO: Update summary.
    /// </summary>
    public interface IMeshRenderer
    {
        bool ShowVoronoi { get; set; }
        bool ShowRegions { get; set; }

        void Zoom(float x, float y, int delta);
        void HandleResize();

        void Initialize();

        void SetData(RenderData data);

        //void SetPoints(float[] points, int inputPoints);
        //void SetTriangles(uint[] triangles);
        //void SetSegments(uint[] segments);
    }
}
